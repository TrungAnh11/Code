/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo;

/**
 *
 * @author NGUYEN TRUNG ANH
 */
public class Queue {
    private Message messageHead ;
    private Message messageTail ;
    public Queue ()
    {
    this.messageHead = null;
    this.messageTail = null ;
    }
    public boolean isEmpty(){
    return (this.messageHead == null );
    }
    public void Enqueue (String messageContent)
    {
    Message newMessage = new Message(messageContent) ;
    if (this.isEmpty())
    {
    this.messageHead = newMessage ; 
    this.messageTail = newMessage ; 
    }
    else 
    {
    this.messageTail.setMessageNext(newMessage);
    this.messageTail = newMessage;
    }
   }
    public void Deqeue()
    {
      if (this.isEmpty())
    {
      System.out.println("This list is empty");
    }
    else 
    {
      while (this.isEmpty())
      {
      this.Deqeue();
      }
    }
        
    }
          
}
