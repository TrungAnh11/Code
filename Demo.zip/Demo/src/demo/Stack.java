/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo;

/**
 *
 * @author NGUYEN TRUNG ANH
 */
public class Stack {
    private final int maxStack;
    private String [] messageContent;
    private int messageTopIndex ;
    public Stack (int maxStack)
    {
    this.maxStack =maxStack;
    this.messageContent = new String [maxStack];
    this.messageTopIndex =-1;
    }
    public boolean isEmpty()
    {
    return (this.messageTopIndex == -1);
    }
    public void Push (String newmessageContent)
    {
     if(this.messageTopIndex == (this.maxStack  -1))
    {
        System.out.println("This Stack is full");
        System.out.println("You can't add a new message to this Stack ");
    }
    else {
    this.messageContent[(++this.messageTopIndex)] = newmessageContent;
    }
    }
    public String Pop(){
       String popMessage = "" ;
       try 
       {
       popMessage = this.messageContent[this.messageTopIndex];
       this.messageTopIndex -- ;
       }
       catch (Exception e ){
           System.out.println("This Stack is empty, can't delete");
       }
       return popMessage;
    }
    public void clear ()
    {
    while (this.isEmpty());
     {
    this.Pop();
     }
    }
}
