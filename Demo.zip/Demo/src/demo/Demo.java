/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo;

import java.util.Scanner;

/**
 *
 * @author NGUYEN TRUNG ANH
 */
public class Demo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner s =new Scanner(System.in);
        Scanner sc =new Scanner(System.in);
        Stack sta = new Stack(100);
        Queue que = new Queue();
        boolean end = false;
        String message = "";
        while(end =true){
            System.out.println("1. Nhập message ");
            System.out.println("2. đẩy message vào stack ");
            System.out.println("3. hiển thị tất cả message");
            System.out.println("4. thoát");
            int choice = s.nextInt();
            switch(choice){
                case 1:
                    System.out.println("Enter a message");
                    message = sc.nextLine();
                    que.Enqueue(message);
                    break;
                case 2:
                    if(message == ""){
                        System.out.println("please try again"); break;
                    }else{
                      sta.Push(message);  
                        System.out.println("complete");
                    }
                    break;
                case 3:
                    System.out.println("----------------------");
                    System.out.println("all message:");
                    sta.reserver();
                    System.out.println("----------------------");
                    break;
                case 4:
                    System.out.println("program closing....");
                    end =false;
                    break;
                default:break;
            }
        }

    }
    
}
